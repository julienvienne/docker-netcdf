/*
  This file is part of CDO. CDO is a collection of Operators to manipulate and analyse Climate model Data.

  Author: Uwe Schulzweida

*/

/*
   This module contains the following operators:

      Compc      eqc             Equal constant
      Compc      nec             Not equal constant
      Compc      lec             Less equal constant
      Compc      ltc             Less then constant
      Compc      gec             Greater equal constant
      Compc      gtc             Greater then constant
*/

#include <cdi.h>

#include "process_int.h"
#include "cdo_vlist.h"
#include "param_conversion.h"
#include "field_functions.h"

static auto func_compc = [](auto hasMissvals, auto n, auto mv, auto &v, const auto cVal, auto binary_operator) {
  if (hasMissvals)
    {
      auto constantIsMissval = dbl_is_equal(cVal, mv);
      if (std::isnan(mv))
        for (size_t i = 0; i < n; ++i)
          v[i] = (dbl_is_equal(v[i], mv) || constantIsMissval) ? mv : binary_operator(v[i], cVal);
      else
        for (size_t i = 0; i < n; ++i) v[i] = (is_equal(v[i], mv) || constantIsMissval) ? mv : binary_operator(v[i], cVal);
    }
  else
    {
      for (size_t i = 0; i < n; ++i) v[i] = binary_operator(v[i], cVal);
    }
};

template <typename T>
static void
comp_function(int operFunc, bool hasMissvals, size_t ngp, T missval, Varray<T> &v, T rconst)
{
  // clang-format off
  if      (operFunc == FieldFunc_EQ) func_compc(hasMissvals, ngp, missval, v, rconst, binary_op_EQ);
  else if (operFunc == FieldFunc_NE) func_compc(hasMissvals, ngp, missval, v, rconst, binary_op_NE);
  else if (operFunc == FieldFunc_LE) func_compc(hasMissvals, ngp, missval, v, rconst, binary_op_LE);
  else if (operFunc == FieldFunc_LT) func_compc(hasMissvals, ngp, missval, v, rconst, binary_op_LT);
  else if (operFunc == FieldFunc_GE) func_compc(hasMissvals, ngp, missval, v, rconst, binary_op_GE);
  else if (operFunc == FieldFunc_GT) func_compc(hasMissvals, ngp, missval, v, rconst, binary_op_GT);
  else cdo_abort("Operator not implemented!");
  // clang-format on
}

static void
comp_function(Field &field, int operFunc, bool hasMissvals, double rconst)
{
  if (field.memType == MemType::Float)
    comp_function(operFunc, hasMissvals, field.size, (float) field.missval, field.vec_f, (float) rconst);
  else
    comp_function(operFunc, hasMissvals, field.size, field.missval, field.vec_d, rconst);
}

static void
add_operators(void)
{
  cdo_operator_add("eqc", FieldFunc_EQ, 0, nullptr);
  cdo_operator_add("nec", FieldFunc_NE, 0, nullptr);
  cdo_operator_add("lec", FieldFunc_LE, 0, nullptr);
  cdo_operator_add("ltc", FieldFunc_LT, 0, nullptr);
  cdo_operator_add("gec", FieldFunc_GE, 0, nullptr);
  cdo_operator_add("gtc", FieldFunc_GT, 0, nullptr);
}

class ModuleCompc
{
  CdoStreamID streamID1;
  int taxisID1;

  CdoStreamID streamID2;
  int taxisID2;

  int operFunc;
  double rconst;

  VarList varList;

public:
  void
  init(void *process)
  {
    cdo_initialize(process);

    add_operators();

    auto operatorID = cdo_operator_id();
    operFunc = cdo_operator_f1(operatorID);

    operator_input_arg("constant value");
    rconst = parameter_to_double(cdo_operator_argv(0));

    streamID1 = cdo_open_read(0);

    auto vlistID1 = cdo_stream_inq_vlist(streamID1);
    auto vlistID2 = vlistDuplicate(vlistID1);

    vlist_unpack(vlistID2);

    taxisID1 = vlistInqTaxis(vlistID1);
    taxisID2 = taxisDuplicate(taxisID1);
    vlistDefTaxis(vlistID2, taxisID2);

    varList_init(varList, vlistID1);

    streamID2 = cdo_open_write(1);
    cdo_def_vlist(streamID2, vlistID2);

    vlistDestroy(vlistID2);
  }

  void
  run()
  {
    Field field;

    int tsID = 0;
    while (true)
      {
        auto nrecs = cdo_stream_inq_timestep(streamID1, tsID);
        if (nrecs == 0) break;

        cdo_taxis_copy_timestep(taxisID2, taxisID1);
        cdo_def_timestep(streamID2, tsID);

        for (int recID = 0; recID < nrecs; ++recID)
          {
            int varID, levelID;
            cdo_inq_record(streamID1, &varID, &levelID);
            field.init(varList[varID]);
            cdo_read_record(streamID1, field);

            auto missval = field.missval;
            auto nmiss = field.nmiss;
            auto hasMissvals = (nmiss > 0 || dbl_is_equal(rconst, missval));

            if (nmiss > 0) cdo_check_missval(missval, varList[varID].name);

            comp_function(field, operFunc, hasMissvals, rconst);

            if (hasMissvals > 0) field_num_mv(field);

            cdo_def_record(streamID2, varID, levelID);
            cdo_write_record(streamID2, field);
          }

        tsID++;
      }
  }

  void
  close()
  {
    cdo_stream_close(streamID2);
    cdo_stream_close(streamID1);

    cdo_finish();
  }
};

void *
Compc(void *process)
{
  ModuleCompc compc;
  compc.init(process);
  compc.run();
  compc.close();

  return nullptr;
}
