#ifndef CDO_MATH_H
#define CDO_MATH_H

// clang-format off
namespace cdo
{
  constexpr double sqr(double x) noexcept { return x * x; }
  unsigned int is_power_of_two(unsigned int  x);
}
// clang-format on

#endif
