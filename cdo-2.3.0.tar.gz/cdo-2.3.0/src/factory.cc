#include <map>
#include <string>
#include <algorithm>
#include "process.h"

std::map<const std::string, std::function<std::shared_ptr<Process>(int p_ID, const std::string &p_operatorNamme,
                                                                   const std::vector<std::string> &operatorArguments)>> &
get_factory()
{
  static std::map<const std::string, std::function<std::shared_ptr<Process>(int p_ID, const std::string &p_operatorNamme,
                                                                            const std::vector<std::string> &operatorArguments)>>
      factory;
  return factory;
}
