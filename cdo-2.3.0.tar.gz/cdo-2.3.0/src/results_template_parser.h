#ifndef RESULTS_TEMPLATE_PARSER_HH
#define RESULTS_TEMPLATE_PARSER_HH

int results_template_parser(void *node, const char *varname);

#endif
