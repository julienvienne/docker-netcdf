#ifndef CDO_MAGICS_MAPPER_HH
#define CDO_MAGICS_MAPPER_HH

int get_magics_parameter_info(const char *user_name, char *param_value);

#endif
