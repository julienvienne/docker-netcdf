#ifndef SHOWATTRIBUTE_H
#define SHOWATTRIBUTE_H

#include "cdo_varlist.h"

void print_attributes(const VarList &varList, int vlistID, int varOrGlobal, int natts, char *argument);

#endif
