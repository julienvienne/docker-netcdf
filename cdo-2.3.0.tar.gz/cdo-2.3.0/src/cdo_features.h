#ifndef CDO_FEATURES_H
#define CDO_FEATURES_H
#include <map>
#include <string>

namespace CdoFeatures
{

int cdo_print_config(const std::string &option);
void cdo_print_features(void);
void cdo_print_libraries(void);
void print_argument_options();

};  // namespace CdoFeatures

#endif
