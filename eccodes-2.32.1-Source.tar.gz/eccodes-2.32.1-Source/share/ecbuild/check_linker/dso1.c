void fun1(void) {}

